let handler = async m => {

let intro = `*Service Bot by WarezXD*
- Mention everyone in group
- Sesuai untuk esport & education group
- chatgpt on
- tiktok download on
- hd image on

*1. Bot Warez ( Number Admin )*
- _Rm5 Per Month_ 
- _Rm10 Permanent_ 

*2. Special Bot Custom*
- _RM10 Per Month_ 

*Kelebihan Custom*
- _guna no sendiri_ 
- _custom hidetag ( not using .h )_ 
- _custom "test" text ( cth: bot warez active )_ 

 *WHATSAPP* 0135087209
`
m.reply(intro)
}
handler.customPrefix = /^(.sewabot|.botws|.botwarez)$/i
handler.command = new RegExp

module.exports = handler