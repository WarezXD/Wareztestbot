let handler = async m => {

let intro = `Bot Warez Kembali Active `
m.reply(intro)
}
handler.customPrefix = /^(tes|tess|test)$/i
handler.command = new RegExp

module.exports = handler
