#!/bin/bash

sudo apt-get update
sudo apt-get upgrade -y
sudo apt-get install git -y
sudo apt-get install nodejs -y
sudo apt-get install ffmpeg -y
sudo apt-get install imagemagick -y
sudo apt-get install npm
npm install
npm start
