global.owner = ['601113256170','60135087209']  
global.mods = ['601113256170'] 
global.prems = ['601113256170']
global.nameowner = 'WarezXD'
global.numberowner = '601113256170' 
global.mail = 'admin@warezgaming.win' 
global.gc = 'https://chat.whatsapp.com/CP5mV2D9IO730HpBgmkuyi'
global.instagram = 'https://instagram.com/faizwarez'
global.wm = '© WarezXD'
global.wait = '_*Wait.. Still Processing...*_'
global.eror = '_*Server Error*_'
global.stiker_wait = '*⫹⫺ Stiker is processing...*'
global.packname = 'Made With'
global.author = 'WarezXD Team'
global.autobio = true // Set true untuk mengaktifkan autobio
global.maxwarn = '2' // Peringatan maksimum

//INI WAJIB DI ISI!//
global.btc = 'warezxd' 
//Daftar terlebih dahulu https://api.botcahx.eu.org

//INI OPTIONAL BOLEH DI ISI BOLEH JUGA ENGGA//
global.lann = 'warezxd'
//Daftar https://api.betabotz.eu.org 

global.APIs = {   
  btc: 'https://api.botcahx.eu.org'
}
global.APIKeys = { 
  'https://api.botcahx.eu.org': 'warezxd' 
}

let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})
